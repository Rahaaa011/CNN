import java.io.*;
import java.net.*;

public class Server {

    private static final int PORT = 5000;

    public static void main(String[] args) {

        try (ServerSocket serverSocket = new ServerSocket(PORT)) {

            System.out.println("Math Server is running on port " + PORT);

            while (true) {
                Socket socket = serverSocket.accept();

                System.out.println("Client connected: "
                        + socket.getInetAddress());

                Thread clientThread = new Thread(() -> {
                    try (
                        BufferedReader input = new BufferedReader(
                            new InputStreamReader(socket.getInputStream()));

                        PrintWriter output = new PrintWriter(
                            socket.getOutputStream(), true)
                    ) {
                        String expression;

                        while ((expression = input.readLine())!= null) {
                            try {
                                double result = calculate(expression);
                                output.println(result);

                                System.out.println(expression
                                        + " = " + result);

                            } catch (Exception e) {
                                output.println("Error: Invalid expression");
                            }
                        }

                    } catch (IOException e) {
                        System.out.println("Client disconnected.");
                    }
                });

                clientThread.start();
            }

        } catch (IOException e) {
            System.out.println("Server error: " + e.getMessage());
        }
    }

    private static double calculate(String expression) {

        String[] parts = expression.trim().split("\\s+");

        if (parts.length!= 3) {
            throw new IllegalArgumentException();
        }

        double a = Double.parseDouble(parts[0]);
        double b = Double.parseDouble(parts[2]);

        switch (parts[1]) {
            case "+":
                return a + b;

            case "-":
                return a - b;

            case "*":
                return a * b;

            case "/":
                if (b == 0) {
                    throw new ArithmeticException();
                }
                return a / b;

            default:
                throw new IllegalArgumentException();
        }
    }
}