import java.io.*;
import java.net.*;
import java.util.Scanner;

public class Client {

    public static void main(String[] args) {

        if (args.length < 2) {
            System.out.println(
                "Usage: java Client <serverIP> <port>");
            return;
        }

        String hostname = args[0];
        int port = Integer.parseInt(args[1]);

        try (
            Socket socket = new Socket(hostname, port);

            BufferedReader input = new BufferedReader(
                new InputStreamReader(socket.getInputStream()));

            PrintWriter output = new PrintWriter(
                socket.getOutputStream(), true);

            Scanner keyboard = new Scanner(System.in)
        ) {

            System.out.println("Connected to Math Server.");
            System.out.println("Example: 1 + 2, 5 - 6, 3 * 4");
            System.out.println("Press Ctrl+C to stop.");

            while (true) {
                System.out.print("Enter expression: ");

                String expression = keyboard.nextLine();

                output.println(expression);

                String response = input.readLine();

                if (response == null) {
                    System.out.println("Server disconnected.");
                    break;
                }

                System.out.println("Server reply: " + response);
            }

        } catch (IOException e) {
            System.out.println("Connection error: "
                    + e.getMessage());
        }
    }
}