
import java.io.*;
import java.net.*;
import java.util.Scanner;

public class HelpDeskClient {

    public static void main(String[] args) {

        String serverAddress = "127.0.0.1";
        int port = 5050;

        try (
            Socket socket = new Socket(serverAddress, port);

            BufferedReader input = new BufferedReader(
                    new InputStreamReader(socket.getInputStream()));

            PrintWriter output = new PrintWriter(
                    socket.getOutputStream(), true);

            Scanner scanner = new Scanner(System.in)
        ) {

            System.out.println(input.readLine());

            while (true) {

                System.out.print("Enter command: ");

                String command = scanner.nextLine();

                output.println(command);

                String response = input.readLine();

                System.out.println("Server: " + response);

                if (command.equalsIgnoreCase("QUIT")) {
                    break;
                }
            }

        } catch (IOException e) {
            System.out.println("Connection error: " + e.getMessage());
        }
    }
}
