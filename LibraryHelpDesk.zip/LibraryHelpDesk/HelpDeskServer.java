
import java.io.*;
import java.net.*;
import java.util.concurrent.CopyOnWriteArrayList;

public class HelpDeskServer {

    static CopyOnWriteArrayList<String> reports =
            new CopyOnWriteArrayList<>();

    public static void main(String[] args) {

        int port = 5050;

        try (ServerSocket server = new ServerSocket(port)) {

            System.out.println("Library Help Desk Server Started");
            System.out.println("Listening on port " + port);

            while (true) {

                Socket client = server.accept();

                System.out.println("Client connected: "
                        + client.getInetAddress()
                        + " Source port: "
                        + client.getPort());

                Thread t = new Thread(() -> handleClient(client));
                t.start();
            }

        } catch (IOException e) {
            System.out.println("Server error: " + e.getMessage());
        }
    }

    public static void handleClient(Socket socket) {

        try (
            Socket client = socket;
            BufferedReader input = new BufferedReader(
                    new InputStreamReader(client.getInputStream()));
            PrintWriter output = new PrintWriter(
                    client.getOutputStream(), true)
        ) {

            output.println("Welcome to Library IT Help Desk!");

            String command;

            while ((command = input.readLine()) != null) {

                System.out.println("Received: " + command);

                String response;

                if (command.equalsIgnoreCase("HELP")) {

                    response = "Commands: HELP, HOURS, WIFI, REPORT <issue>, QUIT";

                } else if (command.equalsIgnoreCase("HOURS")) {

                    response = "Library hours: Monday-Saturday, 8 AM to 8 PM.";

                } else if (command.equalsIgnoreCase("WIFI")) {

                    response = "WiFi: Library-WiFi. Contact IT desk for access.";

                } else if (command.toUpperCase().startsWith("REPORT ")) {

                    String issue = command.substring(7).trim();

                    if (issue.isEmpty()) {
                        response = "ERROR: Please describe your issue.";
                    } else {
                        reports.add(issue);
                        response = "Your technical report has been received.";
                    }

                } else if (command.equalsIgnoreCase("QUIT")) {

                    output.println("Goodbye! Connection closed.");
                    break;

                } else {

                    response = "ERROR: Invalid command. Type HELP.";
                }

                output.println(response);
            }

        } catch (IOException e) {
            System.out.println("Client disconnected.");
        }
    }
}
